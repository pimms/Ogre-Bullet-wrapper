#pragma once

#include <vector>
#include <functional>

#include "plunder.h"


class Node;

class Base
{
protected:
	// Variables
	std::vector<Base*> children;
	Base *parent;

public:
	// Methods
	Base();
	~Base();

	void addChild(Base*);
	void removeChild(Base*, bool=true);
	bool isChild(Base*);

	Vec worldPos();
	float worldRot();

	int childCount();
	Base* childAtIndex(int);

	// Variables
	Vec position;
	float rotation;

	void* userPtr;

	std::function<void(void)> nodeDeallocAlert;
};

