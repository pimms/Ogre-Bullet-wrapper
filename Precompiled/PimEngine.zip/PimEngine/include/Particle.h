#pragma once
#include "PimEngine.h"

class Particle :
    public GameNode
{
public:
    Particle();
    ~Particle();
};

