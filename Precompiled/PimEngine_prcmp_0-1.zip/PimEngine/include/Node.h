#pragma once

#include "PimEngine.h"
#include "Base.h"

class Node : public Base
{
public:
	// Methods
	Node* createChild();
	~Node();
		
	// Variables
		
private:
	// Methods
	Node();
	Node(const Node&) {}
	Node& operator=(const Node&) {}

	// Variables
		
	friend class World;
	friend class Base;
};
